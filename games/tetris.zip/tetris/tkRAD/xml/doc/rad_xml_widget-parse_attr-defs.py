


    def parse_attr_activerelief (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_activerelief(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_activestyle (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_activestyle(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_after (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_after(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_anchor (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_anchor(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_aspect (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_aspect(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_autoseparators (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_autoseparators(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_before (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_before(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_buttonbackground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_buttonbackground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_buttoncursor (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_buttoncursor(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_buttondownrelief (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_buttondownrelief(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_buttonup (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_buttonup(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_class_ (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_class_(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_closeenough (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_closeenough(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_confine (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_confine(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_default (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_default(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_digits (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_digits(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_direction (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_direction(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_disabledbackground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_disabledbackground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_elementborderwidth (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_elementborderwidth(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_exportselection (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_exportselection(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_format (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_format(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_from_ (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_from_(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_handlepad (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_handlepad(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_handlesize (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_handlesize(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_height (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_height(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_highlightbackground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_highlightbackground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_highlightcolor (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_highlightcolor(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_highlightthickness (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_highlightthickness(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_increment (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_increment(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_indicatoron (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_indicatoron(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_insertbackground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_insertbackground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_insertborderwidth (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_insertborderwidth(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_insertofftime (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_insertofftime(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_insertontime (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_insertontime(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_insertwidth (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_insertwidth(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_jump (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_jump(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_justify (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_justify(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_labelanchor (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_labelanchor(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_labelwidget (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_labelwidget(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_length (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_length(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_listvariable (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_listvariable(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_maxundo (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_maxundo(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_minsize (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_minsize(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_offrelief (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_offrelief(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_opaqueresize (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_opaqueresize(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_orient (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_orient(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_overrelief (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_overrelief(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_padx (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_padx(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_pady (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_pady(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_readonlybackground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_readonlybackground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_repeatdelay (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_repeatdelay(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_repeatinterval (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_repeatinterval(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_resolution (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_resolution(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_sashpad (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_sashpad(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_sashrelief (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_sashrelief(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_sashwidth (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_sashwidth(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_scrollregion (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_scrollregion(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_selectbackground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_selectbackground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_selectborderwidth (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_selectborderwidth(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_selectforeground (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_selectforeground(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_selectmode (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_selectmode(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_show (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_show(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_showhandle (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_showhandle(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_showvalue (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_showvalue(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_sliderlength (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_sliderlength(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_sliderrelief (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_sliderrelief(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_spacing1 (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_spacing1(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_spacing2 (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_spacing2(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_spacing3 (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_spacing3(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_sticky (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_sticky(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_tabs (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_tabs(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_takefocus (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_takefocus(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_text (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_text(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_textvariable (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_textvariable(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_tickinterval (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_tickinterval(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_to (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_to(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_troughcolor (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_troughcolor(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_undo (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_undo(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_validate (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_validate(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_validatecommand (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_validatecommand(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_values (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_values(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_width (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_width(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_wrap (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_wrap(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_wraplength (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_wraplength(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_xscrollcommand (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_xscrollcommand(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_xscrollincrement (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_xscrollincrement(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_yscrollcommand (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_yscrollcommand(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def



    def parse_attr_yscrollincrement (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_yscrollincrement(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def
