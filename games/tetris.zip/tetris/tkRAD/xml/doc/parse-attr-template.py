


    def parse_attr_{attr_name} (self, attribute, attrs, **kw):
        r"""
            << NOT IMPLEMENTED YET >>

            no return value (void);
        """

        # ---------------------------------------------------------------FIXME
        print("[WARNING] parse_attr_{attr_name}(): NOT IMPLEMENTED YET")

        # parsed attribute inits

        self._tk_config(attribute)

    # end def
